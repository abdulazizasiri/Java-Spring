package com.udacity.jwdnd.course1.cloudstorage.services;

import com.udacity.jwdnd.course1.cloudstorage.mapper.CredentialMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.Credential;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

@Service
public class CredentialService {

    private CredentialMapper credentialMapper;

    public CredentialService(CredentialMapper credentialMapper) {
        this.credentialMapper = credentialMapper;
    }

    // Create Credentials

    public int createCredentials(Credential credentials) {

        return credentialMapper.insertNewCredentials(new Credential(null, credentials.getUrl(), credentials.getUserName(), credentials.getPassword(), credentials.getKey(),credentials.getUserId() ));

    }

    public Credential [] fetchAllCCredentials(Integer userId){
        Credential [] credentials = credentialMapper.fetchAllUserCredentials(userId);
        return  credentials;
    }

    public int deleteCredentials(Integer id) {
        return credentialMapper.deleteCredentials(id);
    }

    public int editCredentials(Credential cred) {

        return credentialMapper.editCredentials(cred);
    }
}
