package com.udacity.jwdnd.course1.cloudstorage.services;


import com.udacity.jwdnd.course1.cloudstorage.mapper.FileMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.UploadedFile;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
public class FileService {
    private FileMapper fileMapper;

    public FileService(FileMapper fileMapper) {
        this.fileMapper = fileMapper;
    }

    public Integer storeFileData(UploadedFile uploadedFile) {
        String fileName = uploadedFile.getFileName();
        if (fileMapper.getFileByNameId(fileName) != null) {
            return 0 ; // This file exist
        }
        return fileMapper.insertFile(uploadedFile);
    }

    public UploadedFile [] fetchAllFilesPerUsers(Integer userId) {
        UploadedFile [] uploadedFiles = fileMapper.fetchFiles(userId);

        return uploadedFiles;
    }

    public UploadedFile getFile(String fileName) {
        return fileMapper.getFileByNameId(fileName);
    }

    public int deleteFile(Integer id) {

        return fileMapper.deleteNote(id);
    }
}
