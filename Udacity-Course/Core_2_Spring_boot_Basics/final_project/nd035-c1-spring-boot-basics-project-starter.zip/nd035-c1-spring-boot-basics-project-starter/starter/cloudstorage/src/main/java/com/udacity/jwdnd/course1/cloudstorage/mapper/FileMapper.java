package com.udacity.jwdnd.course1.cloudstorage.mapper;

import com.udacity.jwdnd.course1.cloudstorage.model.UploadedFile;
import org.apache.ibatis.annotations.*;

@Mapper
public interface FileMapper {
    @Insert("INSERT INTO FILES (filename, contenttype, filesize,  filedata, userid) VALUES ( #{fileName}, #{contentType}, #{fileSize}, #{fileData}, #{userId} )")
    @Options(useGeneratedKeys = true, keyProperty = "fileId")
    int insertFile(UploadedFile file);

    @Select("SELECT * FROM FILES WHERE userid = #{userid}")
    UploadedFile [] fetchFiles(Integer userid);


    @Select("SELECT * FROM FILES WHERE fileName = #{fileName}")
    UploadedFile getFileByNameId(String fileName );

    @Delete("DELETE FROM FILES WHERE fileId = #{fileId}")
    int deleteNote(Integer noteId);
}
