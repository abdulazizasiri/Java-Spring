package com.udacity.jwdnd.course1.cloudstorage.services;

import com.udacity.jwdnd.course1.cloudstorage.mapper.UserMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.User;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.Base64;

@Service
public class UserService {
    // We need to add the mapper

    private UserMapper userMapper ;
    private HashService hashService ;

    public UserService(UserMapper userMapper, HashService hashService) {
        this.userMapper = userMapper;
        this.hashService = hashService;
    }
    public int createUser(User user) {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        // check if the user name exits.
        User temp = userMapper.getUser(user.getUsername());
        if (temp != null)  {
            // This user has already exited.
            return 0 ;
        }
        String encodedSalt = Base64.getEncoder().encodeToString(salt);
        String hashedPassword = hashService.getHashedValue(user.getPassword(), encodedSalt);
        System.out.println("Create user"+user.getUsername());
        System.out.println("Create user"+user.getLastName());
        System.out.println("Create idd"+user.getUserId());
        System.out.println("Create user"+user.getPassword());
        System.out.println("Create salt"+encodedSalt);
        System.out.println("hashed pass "+hashedPassword);
        return userMapper.insert(new User(null, user.getUsername(), encodedSalt, hashedPassword, user.getFirstName(), user.getLastName()));
    }


}
