package com.udacity.jwdnd.course1.cloudstorage.controller;


import com.udacity.jwdnd.course1.cloudstorage.mapper.UserMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.Credential;
import com.udacity.jwdnd.course1.cloudstorage.model.Note;
import com.udacity.jwdnd.course1.cloudstorage.model.User;
import com.udacity.jwdnd.course1.cloudstorage.services.CredentialService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CredentialController {
    private CredentialService credentialService;
    private UserMapper userMapper;

    public CredentialController(CredentialService credentialService, UserMapper userMapper) {
        this.credentialService = credentialService;
        this.userMapper = userMapper;
    }

    @PostMapping("/credentials")
    public String addNewCredentials(Model model, Authentication auth, @ModelAttribute("newCredentials") Credential credential) {
        // Here, we want to post new data
        System.out.println("Cred id edit: "+credential.getCredentialid());
        System.out.println("Cred url edit: "+credential.getUrl());
        System.out.println("Cred password edit: "+credential.getPassword());
        System.out.println("Cred username edit: "+credential.getUserName());
        if(credential.getCredentialid() != null) {
            model.addAttribute("checked", true);
            model.addAttribute("msg", "You have successfully updated a new credential Click");
            credentialService.editCredentials(credential);
            return "result";
        }
        User user = userMapper.getUser(auth.getName());
        credential.setUserId(user.getUserId());
        model.addAttribute("checked", true);
        model.addAttribute("msg", "You have successfully added a new credential Click");
        credentialService.createCredentials(credential); // We are done adding a new cred.
        return "result";
    }

    @DeleteMapping("credentials/{id}")
    public String deleteCredentials(@PathVariable("id") Integer id) {
        credentialService.deleteCredentials(id);
        return "home";
    }
}
