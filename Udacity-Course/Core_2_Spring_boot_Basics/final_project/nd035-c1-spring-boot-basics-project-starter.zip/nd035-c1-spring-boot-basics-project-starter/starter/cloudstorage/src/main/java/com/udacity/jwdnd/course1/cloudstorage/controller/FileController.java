package com.udacity.jwdnd.course1.cloudstorage.controller;


import com.udacity.jwdnd.course1.cloudstorage.mapper.UserMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.FileForm;
import com.udacity.jwdnd.course1.cloudstorage.model.UploadedFile;
import com.udacity.jwdnd.course1.cloudstorage.model.User;
import com.udacity.jwdnd.course1.cloudstorage.services.FileService;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Controller
public class FileController {
    private UserMapper userMapper ;
    private FileService fileService;


    public FileController(UserMapper userMapper, FileService fileService) {
        this.userMapper = userMapper;
        this.fileService = fileService;
    }
    public @ResponseBody byte[] getFile(@PathVariable("fileName") String fileName) {
        return fileService.getFile(fileName).getFileData();
    }

    @PostMapping(value = "/file", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public String postNewFile(Model model, @ModelAttribute("newFile") FileForm file, Authentication auth) throws IOException {
        Integer fileSize = Math.toIntExact(file.getFileUpload().getSize());
        System.out.println("File size "+fileSize);

        if (fileSize > 1048575) {
            // greater than 1MB
            model.addAttribute("isMaxed", true);
            model.addAttribute("msg", "File size has to be greater than 1MB");
            return "result";
        }
        File tempFile = new File(file.getFileUpload().getOriginalFilename());

        String fileName = tempFile.getName();
        String contentType = file.getFileUpload().getContentType();
        byte [] fileData = file.getFileUpload().getInputStream().readAllBytes();
        User userId = userMapper.getUser(auth.getName());
        UploadedFile fileDataToMapper = new UploadedFile(null,fileName, contentType, fileSize, fileData, userId.getUserId() );

        int fileStored =  fileService.storeFileData(fileDataToMapper); // Calling  a service and then calls the ,apper
        if (fileStored == 0) { // does the file exist
            model.addAttribute("doesExist", true);
            model.addAttribute("msg", "This file name has already existed");
        }
        else {
            model.addAttribute("checked", true);
            model.addAttribute("msg", "You have successfully uploaded a file");
        }

        return "result";

    }

    @DeleteMapping(value = "/file/{id}")
    public String deleteNote( Model model, @PathVariable("id") Integer id)  {
        System.out.println("REQUEST ARRIVE with id: "+id);
        fileService.deleteFile(id);
        model.addAttribute("checked", true);
        model.addAttribute("msg", "You have successfully deleted a file");
        return  "result"; // We need to return success, so that we can update the
    }


}
