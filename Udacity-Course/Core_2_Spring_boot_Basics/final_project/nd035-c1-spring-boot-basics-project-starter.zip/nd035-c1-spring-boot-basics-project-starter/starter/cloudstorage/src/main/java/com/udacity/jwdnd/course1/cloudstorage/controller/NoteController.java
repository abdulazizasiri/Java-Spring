package com.udacity.jwdnd.course1.cloudstorage.controller;

import com.udacity.jwdnd.course1.cloudstorage.mapper.UserMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.Note;
import com.udacity.jwdnd.course1.cloudstorage.model.User;
import com.udacity.jwdnd.course1.cloudstorage.services.NoteService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class NoteController {
    private NoteService noteService;
    private UserMapper userMapper; // this should be used in a service. I think

    public NoteController(NoteService noteService, UserMapper userMapper) {
        this.noteService = noteService;
        this.userMapper = userMapper;
    }


    @PostMapping("/note")
    public String addNewNote(Model model, @ModelAttribute("newNote")Note note, Authentication auth) {
        // This is for updateing although it should have its own endpoing because the front end was not designed to support that.

        if (note.getNoteId() != null) {
            System.out.println("NOT null "+note.getNoteId());

            noteService.updateNote(note); // Updating
            model.addAttribute("checked", true);
            model.addAttribute("msg", "You have successfully updated a note");
            return "result";

        }
        // Creating
        System.out.println(note.getNoteTitle()); //
        System.out.println(note.getNoteDescription());
        User user = userMapper.getUser(auth.getName());
        note.setUserid(user.getUserId());
        noteService.createNote(note);
        model.addAttribute("checked", true);
        model.addAttribute("msg", "You have successfully added a note");

//        System.out.println("User found is "+user.getUserId());
        return "result";
    }

    @DeleteMapping(value = "/note/{id}")
    public String deleteNote(Model model , @PathVariable("id") Integer id)  {
        System.out.println("Note Deleted");
        noteService.deleteNote(id);
        model.addAttribute("checked", true);
        model.addAttribute("msg", "You have successfully deleted a note");

        return "result";
    }


}
