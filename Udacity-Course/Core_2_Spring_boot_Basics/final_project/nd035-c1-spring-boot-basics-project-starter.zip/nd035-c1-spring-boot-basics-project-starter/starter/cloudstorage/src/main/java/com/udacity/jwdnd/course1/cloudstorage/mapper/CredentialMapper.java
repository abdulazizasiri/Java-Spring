package com.udacity.jwdnd.course1.cloudstorage.mapper;

import com.udacity.jwdnd.course1.cloudstorage.model.Credential;
import com.udacity.jwdnd.course1.cloudstorage.model.Note;
import org.apache.ibatis.annotations.*;

@Mapper
public interface CredentialMapper {
    @Insert("INSERT INTO CREDENTIALS ( url, username, key, password, userid) VALUES (#{url}, #{userName}, #{key}, #{password}, #{userId})")
    @Options(useGeneratedKeys = true, keyProperty = "credentialid")
    int insertNewCredentials(Credential cred);

    @Select("SELECT * FROM CREDENTIALS WHERE userid = #{userid}")
    Credential[] fetchAllUserCredentials(Integer userid); // List of notes: one to many

    @Delete("DELETE FROM CREDENTIALS WHERE credentialid = #{credentialid}")
    int deleteCredentials(Integer credentialid);

    @Update("UPDATE CREDENTIALS SET url = #{url}, username= #{userName}, key = #{key}, password = #{password} WHERE credentialid = #{credentialid}")
    int editCredentials(Credential credential);

}

