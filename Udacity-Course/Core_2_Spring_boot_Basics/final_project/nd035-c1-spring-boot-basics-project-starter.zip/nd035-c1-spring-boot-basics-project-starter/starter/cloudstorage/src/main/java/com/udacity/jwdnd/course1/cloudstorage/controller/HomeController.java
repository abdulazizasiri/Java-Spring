package com.udacity.jwdnd.course1.cloudstorage.controller;


import com.udacity.jwdnd.course1.cloudstorage.mapper.UserMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.Credential;
import com.udacity.jwdnd.course1.cloudstorage.model.Note;
import com.udacity.jwdnd.course1.cloudstorage.model.UploadedFile;
import com.udacity.jwdnd.course1.cloudstorage.model.User;
import com.udacity.jwdnd.course1.cloudstorage.services.CredentialService;
import com.udacity.jwdnd.course1.cloudstorage.services.FileService;
import com.udacity.jwdnd.course1.cloudstorage.services.HashService;
import com.udacity.jwdnd.course1.cloudstorage.services.NoteService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.SecureRandom;
import java.util.Base64;

@Controller
@RequestMapping("/home")
public class HomeController {
    private NoteService noteService ;
    private CredentialService credentialService;
    private FileService fileService;
    private UserMapper userMapper;
    private HashService hashService;

    public HomeController(NoteService noteService, CredentialService credentialService, FileService fileService, UserMapper userMapper, HashService hashService) {
        this.noteService = noteService;
        this.credentialService = credentialService;
        this.fileService = fileService;
        this.userMapper = userMapper ;
        this.hashService = hashService;
    }

    @GetMapping
    public String homeSweetHome(Authentication auth, Model model){
        System.out.println("WE are home baby");
        System.out.println("Authh2  " + auth.getName());

        if (auth.isAuthenticated()){
            System.out.println("User us authenticated");
            User user = userMapper.getUser(auth.getName());
            Note [] notes = noteService.fetchUserData(user.getUserId());
            Credential [] creds = credentialService.fetchAllCCredentials(user.getUserId());
            UploadedFile [] allFiles = fileService.fetchAllFilesPerUsers(user.getUserId());
            System.out.println("Note size: "+notes.length);
            System.out.println("Credentials size: "+creds.length);
            System.out.println("Files Size: "+allFiles.length);
            System.out.println("###################################");
            model.addAttribute("notes", notes);
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[16];
            random.nextBytes(salt);

            String encodedSalt = Base64.getEncoder().encodeToString(salt);
            for (Credential cred: creds) {
                String hashedPassword = hashService.getHashedValue(cred.getPassword(), encodedSalt);
                cred.setPassword(hashedPassword);
            }

            model.addAttribute("credentials", creds);
            model.addAttribute("files", allFiles);
        }
        return "home";
    }
}
